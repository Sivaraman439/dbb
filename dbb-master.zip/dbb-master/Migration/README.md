# Migration
This category contains examples of using the [DBB Migration Tool](https://www.ibm.com/support/knowledgecenter/SS6T76_1.0.3/migration.html) 
to migrate z/OS souce code to Git.
