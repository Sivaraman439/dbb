# Automation
This category contains examples of using Z Open Automation Utilities to easily automate common DevOps tasks on z/OS.
