# Snippets 
This category contains small examples demonstrating how to use Groovy and/or DBB APIs that might not be found in the other Sample applications.
